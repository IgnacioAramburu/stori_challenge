package config

const (
	SMTP_HOST     = "smtp.example.com"
	SMTP_PORT     = "587"
	SMTP_USERNAME = "username"
	SMTP_PASSWORD = "password"
)
