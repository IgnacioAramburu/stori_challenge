package cdk

import (
	"github.com/aws/aws-cdk-go/awscdk/v2"
	"github.com/aws/aws-cdk-go/awscdk/v2/awsiam"
	"github.com/aws/aws-cdk-go/awscdk/v2/awslambda"
	"github.com/aws/jsii-runtime-go"
)

type LambdaStackProps struct {
	awscdk.StackProps
}

func NewLambdaStack(scope awscdk.Construct, id string, props *LambdaStackProps) awscdk.Stack {
	stack := awscdk.NewStack(scope, &id, &props.StackProps)

	// Lambda Layer
	layer := awslambda.NewLayerVersion(stack, jsii.String("layer"), &awslambda.LayerVersionProps{
		Code: awslambda.Code_FromAsset(jsii.String("go-layer.zip"), nil),
		CompatibleRuntimes: []awslambda.Runtime{
			awslambda.Runtime_GO_1_X(),
		},
	})

	// Lambda 1
	lambda1 := awslambda.NewFunction(stack, jsii.String("Lambda1"), &awslambda.FunctionProps{
		Runtime: awslambda.Runtime_GO_1_X(),
		Handler: jsii.String("main"),
		Code:    awslambda.Code_FromAsset(jsii.String("cmd/lambda1"), nil),
		Environment: map[string]*string{
			"LAYER_ARN": layer.LayerVersionArn(),
		},
		Layers: []awslambda.ILayerVersion{layer},
	})

	// Lambda 2
	lambda2 := awslambda.NewFunction(stack, jsii.String("Lambda2"), &awslambda.FunctionProps{
		Runtime: awslambda.Runtime_GO_1_X(),
		Handler: jsii.String("main"),
		Code:    awslambda.Code_FromAsset(jsii.String("cmd/lambda2"), nil),
		Environment: map[string]*string{
			"LAYER_ARN": layer.LayerVersionArn(),
		},
		Layers: []awslambda.ILayerVersion{layer},
	})

	// Add IAM policies if necessary (for accessing other services like S3, SNS, etc.)
	lambda1.Role().AddManagedPolicy(awsiam.ManagedPolicy_FromAwsManagedPolicyName(jsii.String("service-role/AWSLambdaBasicExecutionRole")))
	lambda2.Role().AddManagedPolicy(awsiam.ManagedPolicy_FromAwsManagedPolicyName(jsii.String("service-role/AWSLambdaBasicExecutionRole")))

	return stack
}
